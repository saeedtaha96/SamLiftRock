package com.samlifttruck.activity.Adapters;

public class PermFromModelAdapter {
}
