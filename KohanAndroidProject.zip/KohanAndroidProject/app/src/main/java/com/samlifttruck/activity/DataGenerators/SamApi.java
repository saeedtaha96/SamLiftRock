package com.samlifttruck.activity.DataGenerators;

import com.samlifttruck.activity.Models.ProductModel;

import java.util.List;



public interface SamApi {
    //@GET("")
  //  Call<List<ProductModel>> getProduct(@Path("techNo"));
}
