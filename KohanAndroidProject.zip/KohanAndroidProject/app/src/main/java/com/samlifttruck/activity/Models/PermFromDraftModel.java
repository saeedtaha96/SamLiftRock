package com.samlifttruck.activity.Models;

public class PermFromDraftModel {
}
